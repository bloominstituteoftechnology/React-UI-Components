var Container = function Container(props) {
  return React.createElement(
    "div",
    { className: "container row" },
    props.logo,
    props.content
  );
};

var Logo = function Logo() {
  return React.createElement(
    "div",
    { className: "logo col-2" },
    React.createElement("img", { src: "https://ibin.co/3whrpKSBbZ81.png", className: "img-fluid" })
  );
};

var Content = function Content() {
  return React.createElement(
    "div",
    { className: "content col-10" },
    React.createElement(Header, null),
    React.createElement(InnerBox, null)
  );
};

var Header = function Header() {
  return React.createElement(
    "div",
    { className: "header" },
    React.createElement(
      "div",
      { className: "row" },
      React.createElement(
        "div",
        { className: "header-title col-3" },
        "Lambda School"
      ),
      React.createElement(
        "div",
        { className: "header-title-date col" },
        "@LambdaSchool - 26 jan"
      )
    ),
    React.createElement(
      "div",
      { className: "header-title-text-7" },
      "Let's learn React by building simple interfaces with components. Once you feel comfortable using components you are well on your way to mastering React!"
    )
  );
};

var InnerBox = function InnerBox() {
  return React.createElement(
    "div",
    { className: "row" },
    React.createElement(
      "div",
      { className: "inner-box" },
      React.createElement(
        "div",
        { className: "inner-box-img" },
        React.createElement("img", { src: "https://ibin.co/3wnC6SgIOJud.png", className: "img-fluid" })
      ),
      React.createElement(
        "div",
        { className: "inner-box-text-title" },
        "Get started with React"
      ),
      React.createElement(
        "div",
        { className: "inner-box-text" },
        React.createElement(
          "p",
          null,
          "React makes it painless to create interactive UIs. Design simple views for each state in your application."
        )
      ),
      React.createElement(
        "div",
        { className: "inner-box-react-link" },
        "reactjs.org"
      )
    )
  );
};

var App = function App() {
  return React.createElement(Container, {
    logo: React.createElement(Logo, null),
    content: React.createElement(Content, null) });
};

ReactDOM.render(React.createElement(App, null), document.getElementById('target'));