var BasicButton = function BasicButton(props) {
    return React.createElement(
        "button",
        { className: "basicButton " + props.className },
        props['text']
    );
};

var App = function App() {
    return React.createElement(
        "div",
        { className: "container" },
        React.createElement(BasicButton, { className: "display", text: "0" }),
        React.createElement(BasicButton, { className: "bigButton", text: "clear" }),
        React.createElement(BasicButton, { className: "red", text: "/" }),
        React.createElement(BasicButton, { text: "7" }),
        React.createElement(BasicButton, { text: "8" }),
        React.createElement(BasicButton, { text: "9" }),
        React.createElement(BasicButton, { className: "red", text: "X" }),
        React.createElement(BasicButton, { text: "4" }),
        React.createElement(BasicButton, { text: "5" }),
        React.createElement(BasicButton, { text: "6" }),
        React.createElement(BasicButton, { className: "red", text: "-" }),
        React.createElement(BasicButton, { text: "1" }),
        React.createElement(BasicButton, { text: "2" }),
        React.createElement(BasicButton, { text: "3" }),
        React.createElement(BasicButton, { className: "red", text: "+" }),
        React.createElement(BasicButton, { className: "bigButton", text: "0" }),
        React.createElement(BasicButton, { className: "red", text: "=" })
    );
};

ReactDOM.render(React.createElement(App, null), document.getElementById('target'));