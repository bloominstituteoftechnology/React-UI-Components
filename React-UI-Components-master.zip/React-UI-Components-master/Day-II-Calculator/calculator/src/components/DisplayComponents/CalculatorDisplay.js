import React from 'react';
import './Display.css';
