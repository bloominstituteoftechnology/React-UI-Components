import React from 'react';
import './Card.css';
const CardBanner = () => {
	return (
		<div className="img">
			<img className="img" alt="whatever" src="https://reactjs.org/logo-og.png" />
		</div>
	);
};
export default CardBanner;
