import React from 'react';
// import './Header.css';
const Footer = () => {
	return <div className="footer" />;
};

export default Footer;
