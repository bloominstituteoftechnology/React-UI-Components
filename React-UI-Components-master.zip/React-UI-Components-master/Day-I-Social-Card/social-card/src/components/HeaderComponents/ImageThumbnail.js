import React from 'react';
import './Header.css';

const ImageThumbnail = () => {
	return (
		<div className="logo">
			<img className="logo1" alt="" src="https://ibin.co/3whrpKSBbZ81.png" />
		</div>
	);
};

export default ImageThumbnail;
