import React from 'react';
import './Display.css';


export default () => <div className="CalculatorDisplay" />