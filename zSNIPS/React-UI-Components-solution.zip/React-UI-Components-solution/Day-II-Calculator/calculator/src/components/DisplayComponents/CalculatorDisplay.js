import React from 'react';
import './Display.css';

const CalculatorDisplay = () => {
  return <div className="calc-total">0</div>;
};

export default CalculatorDisplay;
